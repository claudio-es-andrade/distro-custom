import os
import sys
import subprocess
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QPushButton, QTextEdit, QLabel, QCheckBox, QTabWidget, QMessageBox, QScrollArea
)
from PyQt6.QtCore import QThread, pyqtSignal


class CommandWorker(QThread):
    output_signal = pyqtSignal(str)
    finished_signal = pyqtSignal(int)

    def __init__(self, command):
        super().__init__()
        self.command = command

    def run(self):
        process = subprocess.Popen(
            self.command,
            shell=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True
        )
        for line in process.stdout:
            self.output_signal.emit(line.strip())
        process.wait()
        self.finished_signal.emit(process.returncode)


class DebianTrixieApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Debian 13 'Trixie' - Assistente de Pós-Instalação (PyQt6)")
        self.resize(1000, 750)

        # Aplicar um estilo global na aplicação para garantir que os textos dos checkboxes fiquem visíveis
        self.setStyleSheet("""
            QWidget {
                background-color: #2b2b2b;
                color: #ffffff;
                font-size: 13px;
            }
            QTabWidget::pane {
                border: 1px solid #444444;
            }
            QTabBar::tab {
                background: #3c3f41;
                color: #ffffff;
                padding: 8px 12px;
                margin-right: 2px;
            }
            QTabBar::tab:selected {
                background: #4b6eaf;
            }
            QCheckBox {
                color: #ffffff;
                spacing: 8px;
                padding: 4px;
            }
            QCheckBox::indicator {
                width: 18px;
                height: 18px;
            }
            QTextEdit {
                background-color: #1e1e1e;
                color: #00ff00;
                font-family: monospace;
                font-size: 12px;
                border: 1px solid #444444;
            }
            QPushButton {
                background-color: #2ecc71;
                color: white;
                font-weight: bold;
                padding: 10px;
                border-radius: 4px;
            }
            QPushButton:hover {
                background-color: #27ae60;
            }
            QPushButton:disabled {
                background-color: #555555;
                color: #888888;
            }
        """)

        # Widget Central e Layout Principal
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout(central_widget)

        # Título
        title = QLabel("<h2> Debian Trixie Pós-Instalação </h2>")
        main_layout.addWidget(title)

        # Abas de Organização
        self.tabs = QTabWidget()
        main_layout.addWidget(self.tabs)

        self.tasks = {}

        # Criar as Abas
        self.create_system_tab()
        self.create_desktop_tab()
        self.create_flatpak_tab()
        self.create_browsers_tab()
        self.create_multimedia_tab()
        self.create_developers_tab()
        self.create_games_tab()
        self.create_hardware_tab()

        # Botão Global de Execução e Área de Log
        btn_layout = QHBoxLayout()
        self.btn_execute = QPushButton("Executar Tarefas Selecionadas")
        self.btn_execute.clicked.connect(self.run_selected_tasks)
        btn_layout.addWidget(self.btn_execute)
        main_layout.addLayout(btn_layout)

        # Botão Sobre
        self.btn_about = QPushButton("Sobre")
        self.btn_about.setStyleSheet("background-color: #4b6eaf;")  # Uma cor diferente para destacar (opcional)
        self.btn_about.clicked.connect(self.show_about_dialog)
        btn_layout.addWidget(self.btn_about)

        main_layout.addWidget(QLabel("<b>Log de Execução (Terminal):</b>"))
        self.log_output = QTextEdit()
        self.log_output.setReadOnly(True)
        main_layout.addWidget(self.log_output)

    def show_about_dialog(self):
        QMessageBox.about(
            self,
            "Sobre o Assistente",
            "<h3>Debian 13 'Trixie' - Assistente de Pós-Instalação</h3>"
            "<p><b>Versão:</b> 1.0</p>"
            "<p>Este programa automatiza a instalação de softwares, "
            "configurações de sistema, ambientes gráficos e utilitários "
            "essenciais para o seu Debian Trixie.</p>"
            "<p>Desenvolvido com Python e PyQt6.</p>"
            "<p><b>Contato: claudioe.s.andrade@gmail.com</b> </p>"
            "<p><b>GitHub: https://www.github.com/claudio-es-andrade/distro-custom</b> </p>"
        )

    def add_tab_content(self, title, items):
        tab = QWidget()
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        content_widget = QWidget()
        layout = QVBoxLayout(content_widget)

        for text, cmd_key in items:
            chk = QCheckBox(text)
            layout.addWidget(chk)
            self.tasks[cmd_key] = chk

        layout.addStretch()
        scroll.setWidget(content_widget)

        tab_layout = QVBoxLayout(tab)
        tab_layout.addWidget(scroll)
        self.tabs.addTab(tab, title)

    def create_system_tab(self):
        items = [
            ("Modificar sources.list (Main, Contrib, Non-Free, Backports)",
             "cp /etc/apt/sources.list /etc/apt/sources.list_ORIGINAL && "
             "cat << 'EOF' > /etc/apt/sources.list\n"
             "deb http://deb.debian.org/debian/ trixie main contrib non-free non-free-firmware\n"
             "deb http://security.debian.org/debian-security trixie-security main contrib non-free non-free-firmware\n"
             "deb http://deb.debian.org/debian trixie-updates main contrib non-free non-free-firmware\n"
             "deb http://deb.debian.org/debian trixie-backports main contrib non-free non-free-firmware\n"
             "EOF\n"
             "apt update" ),

            ("Transição para o debian.sources",
             "apt modernize-sources -y &&"
             "echo 'Novo arquivo em /etc/apt/sources.list.d/debian.sources' &&"
            "cat /etc/apt/sources.list.d/debian.sources"
            ),

            ("Instalar e configurar Locales",
             "apt install locales -y && "
             "sed -i 's/^# *\\(pt_BR.UTF-8 UTF-8\\)/\\1/' /etc/locale.gen && "
             "sed -i 's/^# *\\(en_US.UTF-8 UTF-8\\)/\\1/' /etc/locale.gen && "
             "locale-gen && "
             "update-locale LANG=pt_BR.UTF-8"),

            ("Instalar NALA (Frontend APT avançado)", "apt install nala -y"),

            ("Instalar EXTREPO",
             "apt install extrepo -y && "
             "sed -i 's/^# - contrib/- contrib/' /etc/extrepo/config.yaml && "
             "sed -i 's/^# - non-free/- non-free/' /etc/extrepo/config.yaml && "
             "echo '- non-free-firmware' >> /etc/extrepo/config.yaml"),

            ("Instalar Debian Reference (En e Pt-Br)",
             "apt remove -y debian-reference-it debian-reference-es && apt install -y debian-reference-en debian-reference-pt-br"),

            ("Instalar GNOME Tweaks e Extension Manager", "apt install -y gnome-tweaks gnome-shell-extension-manager"),

            ("Instalar Firewall UFW e GUFW", "apt install -y ufw gufw && systemctl enable ufw && systemctl start ufw"),

            ("Instalar FirewallD", "apt install -y firewalld firewall-applet && systemctl enable firewalld && systemctl start firewalld"),

            ("Instalar YAD e Tasksel", "apt install -y yad tasksel")

        ]
        self.add_tab_content("Sistema e Repositórios", items)

    def create_desktop_tab(self):
        items = [
            ("Instalar o GNOME Desktop ",
             "apt install -y task-gnome-desktop"),

            ("Instalar o KDE Plasma Desktop ",
             "apt install -y task-kde-desktop"),

            ("Instalar o XFCE Desktop ",
             "apt install -y task-xfce-desktop"),

            ("Instalar o LXDE Desktop ",
             "apt install -y task-lxde-desktop"),

            ("Instalar o CINNAMON Desktop ",
             "apt install -y task-cinnamon-desktop"),

            ("Instalar o MATE Desktop ",
             "apt install -y task-mate-desktop"),

        ]
        self.add_tab_content("Ambientes de Desktop", items)

    def create_flatpak_tab(self):
        items = [
            ("Habilitar Flatpak e Plugin GNOME Software (Flathub)",
             "apt install -y flatpak gnome-software-plugin-flatpak && "
             "flatpak remote-add --if-not-exists flathub https://flathub.org/repo/flathub.flatpakrepo"),

            ("Habilitar Flatpak e Plugin KDE Discover (Flathub)",
             "apt install -y flatpak plasma-discover-backend-flatpak && "
             "flatpak remote-add --if-not-exists flathub https://flathub.org/repo/flathub.flatpakrepo"),

            ("Instalar Loja de Aplicativos Bazaar (Flatpak)",
             "apt install -y flatpak &&"
             "flatpak remote-add --if-not-exists flathub https://flathub.org/repo/flathub.flatpakrepo &&"
             "flatpak install -y flathub io.github.kolunmi.Bazaar")
        ]
        self.add_tab_content("Flatpak e Lojas", items)

    def create_browsers_tab(self):
        items = [

            ("Instalar Mozilla Firefox (Repositório Oficial .deb da Mozilla)",
             "install -d -m 0755 /etc/apt/keyrings && "
             "wget -q https://packages.mozilla.org/apt/repo-signing-key.gpg -O- | tee /etc/apt/keyrings/packages.mozilla.org.asc > /dev/null && "
             "printf 'Types: deb\\nURIs: https://packages.mozilla.org/apt\\nSuites: mozilla\\nComponents: main\\nSigned-By: /etc/apt/keyrings/packages.mozilla.org.asc\\n' > /etc/apt/sources.list.d/mozilla.sources && "
             "printf 'Package: *\\nPin: origin packages.mozilla.org\\nPin-Priority: 1000\\n' > /etc/apt/preferences.d/mozilla && "
             "apt update && "
             "apt install -y firefox"),

            ("Instalar Google Chrome",
             "curl -fSsL https://dl.google.com/linux/linux_signing_key.pub | gpg --dearmor | tee /usr/share/keyrings/google-chrome.gpg > /dev/null && echo 'deb [arch=amd64 signed-by=/usr/share/keyrings/google-chrome.gpg] http://dl.google.com/linux/chrome/deb/ stable main' > /etc/apt/sources.list.d/google-chrome.list && apt update && apt install -y google-chrome-stable"),

            ("Instalar Opera",
             "curl -fSsL https://deb.opera.com/archive.key | gpg --dearmor | tee /usr/share/keyrings/opera.gpg > /dev/null && echo 'deb [arch=amd64 signed-by=/usr/share/keyrings/opera.gpg] http://deb.opera.com/opera-stable/ stable main' > /etc/apt/sources.list.d/opera.list && apt update && apt install -y opera-stable"),

            ("Instalar Microsoft Edge",
             "curl https://packages.microsoft.com/keys/microsoft.asc | gpg --dearmor > /etc/apt/trusted.gpg.d/microsoft.gpg && echo 'deb [arch=amd64] https://packages.microsoft.com/repos/edge/ stable main' > /etc/apt/sources.list.d/microsoft-edge.list && apt update && apt install -y microsoft-edge-stable"),

            ("Instalar Chromium", "apt install -y chromium"),

            ("Instalar Mozilla Firefox (Flatpak)", "flatpak install -y flathub org.mozilla.firefox"),

            ("Instalar LibreWolf (Flatpak)", "flatpak install -y flathub io.gitlab.librewolf-community"),

            ("Instalar Zen Browser (Flatpak)", "flatpak install -y flathub app.zen_browser.zen"),

            ("Instalar Vivaldi (Flatpak)", "flatpak install -y flathub com.vivaldi.Vivaldi")
        ]
        self.add_tab_content("Navegadores", items)

    def create_multimedia_tab(self):
        items = [
            ("Instalar Codecs Multimédia",
             "apt install -y faad ffmpeg gstreamer1.0-plugins-bad gstreamer1.0-plugins-good gstreamer1.0-plugins-ugly libavcodec-extra"),

            ("Instalar e Configurar Codecs para DVD criptografado (libdvd-pkg)",
             "echo 'libdvd-pkg libdvd-pkg/first-install select true' | debconf-set-selections && "
             "echo 'libdvd-pkg libdvd-pkg/process_libdvdcss select true' | debconf-set-selections && "
             "apt install -y libdvd-pkg && "
             "dpkg-reconfigure libdvd-pkg"),

            ("Instalar Compactadores/Extratores",
             "apt install -y arc arj cabextract lhasa p7zip p7zip-full p7zip-rar rar unrar unace unzip xz-utils zip"),

            ("Instalar Fontes da Microsoft",
             "apt install -y cabextract curl fontconfig xfonts-utils ttf-mscorefonts-installer"),

            ("Instalar VLC Player", "apt install -y vlc"),

            ("Instalar Audacious", "apt install -y audacious"),

            ("Instalar SMPlayer", "apt install -y smplayer"),

            ("Instalar Kodi", "apt install -y kodi"),

            ("Instalar Spotify",
             "curl -sS https://download.spotify.com/debian/pubkey_C85668DF69375001.gpg | gpg --dearmor | tee /etc/apt/keyrings/spotify.gpg > /dev/null && echo 'deb [arch=amd64 signed-by=/usr/share/keyrings/spotify.gpg] http://repository.spotify.com stable non-free' > /etc/apt/sources.list.d/spotify.list && apt update && apt install -y spotify-client"),

            ("Instalar GIMP", "apt install -y gimp"),

            ("Instalar Blender", "apt install -y blender"),

            ("Instalar OBS Studio", "apt install -y obs-studio")
        ]
        self.add_tab_content("Multimédia e Apps", items)

    def create_developers_tab(self):
        items = [

            ("Instalar Python 3, Pip e Venv",
             "apt install -y python3 python3-dev python3-pip python3-venv libpython3-dev"),

            ("Instalar Build-Essential, CMake e Ferramentas C/C++",
             "apt install -y build-essential ccache cmake autoconf automake libtool libssl-dev zlib1g-dev"),

            ("Instalar OpenJDK Java LTS 25 ", "apt install -y openjdk-25-jdk"),

            ("Instalar NodeJS e NPM", "apt install -y nodejs npm"),

            ("Instalar MariaDB Server", "apt install -y mariadb-server"),

            ("Instalar PostgreSQL", "apt install -y postgresql postgresql-contrib"),

            ("Instalar Git, Curl e Wget", "apt install -y git curl wget"),

            ("Instalar Docker e Docker Compose",
             "apt install -y apt-transport-https ca-certificates curl gnupg && curl -fsSL https://download.docker.com/linux/debian/gpg -o /etc/apt/keyrings/docker.asc && echo 'deb [arch=amd64 signed-by=/usr/share/keyrings/docker.asc] https://download.docker.com/linux/debian trixie stable' > /etc/apt/sources.list.d/docker.list && apt update && apt install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin"),

            ("Instalar Distrobox"," apt install -y distrobox"),

            ("Instalar Visual Studio Code",
             "wget -qO- https://packages.microsoft.com/keys/microsoft.asc | gpg --dearmor > /etc/apt/trusted.gpg.d/microsoft.gpg && echo 'deb [arch=amd64] https://packages.microsoft.com/repos/vscode stable main' > /etc/apt/sources.list.d/vscode.list && apt update && apt install -y code"),

            ("Instalar DBeaver Community (Flatpak)", "flatpak install -y flathub io.dbeaver.DBeaverCommunity")
        ]
        self.add_tab_content("Desenvolvimento", items)

    def create_games_tab(self):
        items = [

            ("Habilitar suporte a 32-bits e Instalar Steam (com dependências completas)",
             "dpkg --add-architecture i386 && "
             "apt update && "
             "apt install -y mesa-vulkan-drivers libglx-mesa0:i386 mesa-vulkan-drivers:i386 libgl1-mesa-dri:i386 steam"),

            ("Instalar Emulador Dolphin (GameCube/Wii - Flatpak)", "flatpak install -y flathub org.DolphinEmu.dolphin-emu"),

            ("Instalar Emulador PCSX2 (PlayStation 2 - Flatpak)", "flatpak install -y flathub net.pcsx2.PCSX2"),

            ("Instalar Bottles (Crossover Windows - Flatpak)", "flatpak install -y flathub com.usebottles.bottles"),

            ("Instalar Wine Staging/Stable",
             "x-terminal-emulator -e bash -c 'dpkg --add-architecture i386 && mkdir -pm755 /etc/apt/keyrings && wget -O - https://dl.winehq.org/wine-builds/winehq.key | gpg --dearmor -o /etc/apt/keyrings/winehq-archive.key && apt update && apt install -y --install-recommends winehq-stable; echo -e \"\\nPressione ENTER para fechar esta janela...\"; read'"),


        ]
        self.add_tab_content("Jogos e Emuladores", items)

    def create_hardware_tab(self):
        items = [
            ("Instalar Microcode Intel e Remover AMD", "apt install -y intel-microcode && apt remove -y amd64-microcode"),

            ("Instalar Microcode AMD e Remover Intel", "apt install -y amd64-microcode && apt remove -y intel-microcode"),

            ("Instalar Drivers NVIDIA Recentes", "apt install -y linux-headers-amd64 dkms nvidia-driver nvidia-smi nvidia-settings cuda"),

            ("Instalar GParted (Particionamento)", "apt install -y gparted"),

            ("Instalar GDebi e Synaptic (Para Pacotes Específicos)", "apt install -y gdebi synaptic"),

            ("Otimizar Zonas e Parâmetros Sysctl (Swappiness)",  "sysctl -w vm.swappiness=10 && sysctl -w vm.vfs_cache_pressure=50 && sysctl --system"),

            ("Melhorar bateria do Notebook (TLP)", "apt install -y tlp tlp-rdw && systemctl enable tlp && tlp start"),

            ("Atualizar Sistema Completo (Apt e Flatpak)", "flatpak update -y && apt update && apt upgrade -y && apt autoremove -y")
        ]
        self.add_tab_content("Hardware e Sistema", items)

    def log(self, text):
        self.log_output.append(text)
        self.log_output.verticalScrollBar().setValue(self.log_output.verticalScrollBar().maximum())

    def run_selected_tasks(self):
        commands_to_run = []
        for cmd, chk in self.tasks.items():
            if chk.isChecked():
                commands_to_run.append(cmd)

        if not commands_to_run:
            QMessageBox.warning(self, "Aviso", "Nenhuma tarefa foi selecionada!")
            return

        full_command = " && ".join(commands_to_run)
        self.log(f"\n--- A INICIAR EXECUÇÃO DOS COMANDOS ---\n")

        self.btn_execute.setEnabled(False)
        self.worker = CommandWorker(full_command)
        self.worker.output_signal.connect(self.log)
        self.worker.finished_signal.connect(self.on_execution_finished)
        self.worker.start()

    def on_execution_finished(self, code):
        self.btn_execute.setEnabled(True)
        if code == 0:
            self.log("\n--- TODAS AS TAREFAS FORAM EXECUTADAS COM SUCESSO! ---\n")
            QMessageBox.information(self, "Sucesso", "Procedimento realizado com sucesso!")
        else:
            self.log(f"\n--- A EXECUÇÃO TERMINOU COM CÓDIGO DE ERRO: {code} ---\n")
            QMessageBox.warning(self, "Atenção", "Alguns comandos terminaram com erros. Verifique o log.")


# if __name__ == "__main__":
if __name__ == "__main__":
    app = QApplication(sys.argv)

    # Verifica se NÃO é root
    if os.geteuid() != 0:
        script_path = os.path.abspath(sys.argv[0])

        # Captura as variáveis do ambiente gráfico atual
        display = os.environ.get("DISPLAY", ":0")
        xauth = os.environ.get("XAUTHORITY", "")

        try:
            # Passa o DISPLAY e XAUTHORITY junto com o pkexec para manter a interface gráfica visível
            os.execlp(
                "pkexec",
                "pkexec",
                "env",
                f"DISPLAY={display}",
                f"XAUTHORITY={xauth}",
                sys.executable,
                script_path,
                *sys.argv[1:]
            )
        except Exception as e:
            QMessageBox.critical(None, "Erro de Permissão",
                                 f"Não foi possível elevar os privilégios com pkexec.\nErro: {e}")
            sys.exit(1)

    window = DebianTrixieApp()
    window.show()
    sys.exit(app.exec())

    #app = QApplication(sys.argv)
