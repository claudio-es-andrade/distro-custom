import os
import sys
import subprocess
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QPushButton, QTextEdit, QLabel, QCheckBox, QTabWidget, QMessageBox, QScrollArea, QInputDialog
)
from PyQt6.QtCore import QThread, pyqtSignal


class CommandWorker(QThread):
    output_signal = pyqtSignal(str)
    finished_signal = pyqtSignal(int)

    def __init__(self, command):
        super().__init__()
        self.command = command

    def run(self):
        process = subprocess.Popen(
            self.command,
            shell=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True
        )
        for line in process.stdout:
            self.output_signal.emit(line.strip())
        process.wait()
        self.finished_signal.emit(process.returncode)


class DebianTrixieApp(QMainWindow):

    def __init__(self):
        super().__init__()
        self.setWindowTitle("Debian 13 'Trixie' - Assistente de Pós-Instalação")
        self.resize(1000, 750)

        # Definição dos Temas
        self.dark_stylesheet = """
            QWidget {
                background-color: #353b48;
                color: #ffffff;
                font-size: 13px;
            }
            QTabWidget::pane { border: 1px solid #444444; }
            QTabBar::tab { background: #3c3f41; color: #ffffff; padding: 8px 12px; margin-right: 2px; }
            QTabBar::tab:selected { background: #4b6eaf; }
            QCheckBox { color: #ffffff; spacing: 8px; padding: 4px; }
            QCheckBox::indicator { width: 18px; height: 18px; }
            QTextEdit { background-color: #2f3640; color: #00ff00; font-family: monospace; font-size: 12px; border: 1px solid #444444; }
            QPushButton { background-color: #2ecc71; color: white; font-weight: bold; padding: 10px; border-radius: 4px; }
            QPushButton:hover { background-color: #27ae60; }
            QPushButton:disabled { background-color: #555555; color: #888888; }
        """

        # Tema Claro Suave (Soft Light) - tons pastéis e cinza claro para não ofuscar
        self.light_stylesheet = """
            QWidget {
                background-color: #d5d8dc;
                color: #222222;
                font-size: 13px;
            }
            QTabWidget::pane { border: 1px solid #cccccc; }
            QTabBar::tab { background: #e1e4e8; color: #333333; padding: 8px 12px; margin-right: 2px; }
            QTabBar::tab:selected { background: #3498db; color: white; }
            QCheckBox { color: #222222; spacing: 8px; padding: 4px; }
            QCheckBox::indicator { width: 18px; height: 18px; }
            QTextEdit { background-color: #f5f6fa; color: #1e272e; font-family: monospace; font-size: 12px; border: 1px solid #b2bec3; }
            QPushButton { background-color: #27ae60; color: white; font-weight: bold; padding: 10px; border-radius: 4px; }
            QPushButton:hover { background-color: #219653; }
            QPushButton:disabled { background-color: #dddddd; color: #888888; }
        """

        # Começa com o tema escuro (ou mude para self.light_stylesheet se preferir iniciar no claro)
        self.is_dark_mode = True
        self.setStyleSheet(self.dark_stylesheet)
    
        # Widget Central e Layout Principal
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout(central_widget)

        # Título
        title = QLabel("<h2> Debian Trixie Pós-Instalação </h2>")
        main_layout.addWidget(title)

        # Abas de Organização
        self.tabs = QTabWidget()
        main_layout.addWidget(self.tabs)

        self.tasks = {}

        # Criar as Abas
        self.create_system_tab()
        self.create_desktop_tab()
        self.create_flatpak_tab()
        self.create_browsers_tab()
        self.create_multimedia_tab()
        self.create_virtualization_tab()
        self.create_developers_tab()
        self.create_games_tab()
        self.create_hardware_tab()

        # Botão Global de Execução e Área de Log
        btn_layout = QHBoxLayout()
        self.btn_execute = QPushButton("Executar Tarefas Selecionadas")
        self.btn_execute.clicked.connect(self.run_selected_tasks)
        btn_layout.addWidget(self.btn_execute)
        main_layout.addLayout(btn_layout)

        # Botão Sobre
        self.btn_about = QPushButton("Sobre")
        self.btn_about.setStyleSheet("background-color: #4b6eaf;")  # Uma cor diferente para destacar (opcional)
        self.btn_about.clicked.connect(self.show_about_dialog)
        btn_layout.addWidget(self.btn_about)

        # Botão DESINSTALAR
        self.btn_uninstall = QPushButton("Desinstalar App")
        self.btn_uninstall.setStyleSheet("background-color: #c0392b;")  # Vermelho para destacar a ação crítica
        self.btn_uninstall.clicked.connect(self.uninstall_self)
        btn_layout.addWidget(self.btn_uninstall)

        main_layout.addWidget(QLabel("<b>Log de Execução (Terminal):</b>"))
        self.log_output = QTextEdit()
        self.log_output.setReadOnly(True)
        main_layout.addWidget(self.log_output)

        # Botão para alternar o Tema
        self.btn_theme = QPushButton("Alternar Tema (Claro/Escuro)")
        self.btn_theme.setStyleSheet("background-color: #8e44ad;")  # Roxo diferenciado
        self.btn_theme.clicked.connect(self.toggle_theme)
        btn_layout.addWidget(self.btn_theme)

    def toggle_theme(self):
        if self.is_dark_mode:
            self.setStyleSheet(self.light_stylesheet)
            self.is_dark_mode = False
            self.log("--- TEMA ALTERADO: Modo Claro ativado ---")
        else:
            self.setStyleSheet(self.dark_stylesheet)
            self.is_dark_mode = True
            self.log("--- TEMA ALTERADO: Modo Escuro ativado ---")

    def show_about_dialog(self):
        QMessageBox.about(
            self,
            "Sobre o Assistente",
            "<h3>Debian 13 'Trixie' - Assistente de Pós-Instalação</h3>"
            "<p><b>Versão:</b> 1.5</p>"
            "<p>Este programa automatiza a instalação de softwares, "
            "configurações de sistema, ambientes gráficos e utilitários "
            "essenciais para o seu Debian Trixie.</p>"
            "<p>Desenvolvido com Python e PyQt6.</p>"
            "<p><b>Contato: claudioe.s.andrade@gmail.com</b> </p>"
            "<p><b>GitHub: https://www.github.com/claudio-es-andrade/distro-custom</b> </p>"
        )

    def uninstall_self(self):
        # 1. Janela de confirmação principal da desinstalação
        reply = QMessageBox.question(
            self,
            "Desinstalar Aplicação",
            "Tem certeza de que deseja desinstalar o Assistente Debian Trixie do seu sistema?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No
        )

        if reply == QMessageBox.StandardButton.Yes:
            # 2. Janela secundária perguntando sobre o autoremove (substitui o antigo Zenity)
            auto_reply = QMessageBox.question(
                self,
                "Limpeza do Sistema",
                "Deseja remover também as dependências órfãs e limpar o cache associado ao sistema?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No
            )

            # Monta o comando de acordo com a escolha do usuário
            if auto_reply == QMessageBox.StandardButton.Yes:
                uninstall_cmd = "apt-get purge -y trixie-post-install && apt-get autoremove -y"
            else:
                uninstall_cmd = "apt-get purge -y trixie-post-install"

            self.log("\n--- INICIANDO A DESINSTALAÇÃO DO APLICATIVO ---\n")
            self.btn_execute.setEnabled(False)
            self.btn_uninstall.setEnabled(False)

            # Reaproveita a sua classe CommandWorker para rodar a remoção em segundo plano
            self.worker = CommandWorker(uninstall_cmd)
            self.worker.output_signal.connect(self.log)
            self.worker.finished_signal.connect(self.on_uninstallation_finished)
            self.worker.start()

    def on_uninstallation_finished(self, code):
        if code == 0:
            QMessageBox.information(
                self,
                "Desinstalação Concluída",
                "O programa foi removido com sucesso. O aplicativo será fechado."
            )
            sys.exit(0)
        else:
            QMessageBox.warning(
                self,
                "Atenção",
                "A desinstalação terminou com erros. Verifique o log de execução."
            )
            self.btn_execute.setEnabled(True)
            self.btn_uninstall.setEnabled(True)

    def add_tab_content(self, title, items):
        tab = QWidget()
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        content_widget = QWidget()
        layout = QVBoxLayout(content_widget)

        for text, cmd_key in items:
            chk = QCheckBox(text)
            layout.addWidget(chk)
            self.tasks[cmd_key] = chk

        layout.addStretch()
        scroll.setWidget(content_widget)

        tab_layout = QVBoxLayout(tab)
        tab_layout.addWidget(scroll)
        self.tabs.addTab(tab, title)

    def create_system_tab(self):
        items = [
            ("Modificar sources.list (Main, Contrib, Non-Free, Backports)",
             "cp /etc/apt/sources.list /etc/apt/sources.list_ORIGINAL && "
             "cat << 'EOF' > /etc/apt/sources.list\n"
             "deb http://deb.debian.org/debian/ trixie main contrib non-free non-free-firmware\n"
             "deb http://security.debian.org/debian-security trixie-security main contrib non-free non-free-firmware\n"
             "deb http://deb.debian.org/debian trixie-updates main contrib non-free non-free-firmware\n"
             "deb http://deb.debian.org/debian trixie-backports main contrib non-free non-free-firmware\n"
             "EOF\n"
             "apt update" ),

            ("Transição para o debian.sources",
             "apt modernize-sources -y &&"
             "echo 'Novo arquivo em /etc/apt/sources.list.d/debian.sources' &&"
            "cat /etc/apt/sources.list.d/debian.sources"
            ),

            ("Instalar e configurar Locales",
             "apt install locales -y && "
             "sed -i 's/^# *\\(pt_BR.UTF-8 UTF-8\\)/\\1/' /etc/locale.gen && "
             "sed -i 's/^# *\\(en_US.UTF-8 UTF-8\\)/\\1/' /etc/locale.gen && "
             "locale-gen && "
             "update-locale LANG=pt_BR.UTF-8"),

            ("Instalar NALA (Frontend APT avançado)", "apt install nala -y"),

            ("Instalar EXTREPO",
             "apt install extrepo -y && "
             "sed -i 's/^# - contrib/- contrib/' /etc/extrepo/config.yaml && "
             "sed -i 's/^# - non-free/- non-free/' /etc/extrepo/config.yaml && "
             "echo '- non-free-firmware' >> /etc/extrepo/config.yaml"),

            ("Instalar Debian Reference (En e Pt-Br)",
             "apt remove -y debian-reference-it debian-reference-es && apt install -y debian-reference-en debian-reference-pt-br"),

            ("Instalar GNOME Tweaks e Extension Manager", "apt install -y gnome-tweaks gnome-shell-extension-manager"),

            ("Instalar Firewall UFW e GUFW", "apt install -y ufw gufw && systemctl enable ufw && systemctl start ufw"),

            ("Instalar FirewallD", "apt install -y firewalld firewall-applet && systemctl enable firewalld && systemctl start firewalld"),

            ("Instalar YAD e Tasksel", "apt install -y yad tasksel")

        ]
        self.add_tab_content("Sistema e Repositórios", items)

    def create_desktop_tab(self):
        items = [
            ("Instalar o GNOME Desktop ",
             "apt install -y task-gnome-desktop"),

            ("Instalar o KDE Plasma Desktop ",
             "apt install -y task-kde-desktop"),

            ("Instalar o XFCE Desktop ",
             "apt install -y task-xfce-desktop"),

            ("Instalar o LXDE Desktop ",
             "apt install -y task-lxde-desktop"),

            ("Instalar o CINNAMON Desktop ",
             "apt install -y task-cinnamon-desktop"),

            ("Instalar o MATE Desktop ",
             "apt install -y task-mate-desktop"),

        ]
        self.add_tab_content("Ambientes de Desktop", items)

    def create_flatpak_tab(self):
        items = [
            ("Habilitar Flatpak e Plugin GNOME Software (Flathub)",
             "apt install -y flatpak gnome-software-plugin-flatpak && "
             "flatpak remote-add --if-not-exists flathub https://flathub.org/repo/flathub.flatpakrepo"),

            ("Habilitar Flatpak e Plugin KDE Discover (Flathub)",
             "apt install -y flatpak plasma-discover-backend-flatpak && "
             "flatpak remote-add --if-not-exists flathub https://flathub.org/repo/flathub.flatpakrepo"),

            ("Instalar Loja de Aplicativos Bazaar (Flatpak)",
             "apt install -y flatpak &&"
             "flatpak remote-add --if-not-exists flathub https://flathub.org/repo/flathub.flatpakrepo &&"
             "flatpak install -y flathub io.github.kolunmi.Bazaar")

        ]
        self.add_tab_content("Flatpak e Lojas", items)

    def create_browsers_tab(self):
        items = [

            ("Instalar Mozilla Firefox",
             "install -d -m 0755 /etc/apt/keyrings && "
             "wget -q https://packages.mozilla.org/apt/repo-signing-key.gpg -O- | tee /etc/apt/keyrings/packages.mozilla.org.asc > /dev/null && "
             "printf 'Types: deb\\nURIs: https://packages.mozilla.org/apt\\nSuites: mozilla\\nComponents: main\\nSigned-By: /etc/apt/keyrings/packages.mozilla.org.asc\\n' > /etc/apt/sources.list.d/mozilla.sources && "
             "printf 'Package: *\\nPin: origin packages.mozilla.org\\nPin-Priority: 1000\\n' > /etc/apt/preferences.d/mozilla && "
             "apt update && "
             "apt install -y firefox"),

            ("Instalar Google Chrome",
             "curl -fSsL https://dl.google.com/linux/linux_signing_key.pub | gpg --dearmor | tee /usr/share/keyrings/google-chrome.gpg > /dev/null && echo 'deb [arch=amd64 signed-by=/usr/share/keyrings/google-chrome.gpg] http://dl.google.com/linux/chrome/deb/ stable main' > /etc/apt/sources.list.d/google-chrome.list && apt update && apt install -y google-chrome-stable"),

            ("Instalar Microsoft Edge",
             "curl https://packages.microsoft.com/keys/microsoft.asc | gpg --dearmor > /etc/apt/trusted.gpg.d/microsoft.gpg && echo 'deb [arch=amd64] https://packages.microsoft.com/repos/edge/ stable main' > /etc/apt/sources.list.d/microsoft-edge.list && apt update && apt install -y microsoft-edge-stable"),

            ("Instalar Chromium", "apt install -y chromium"),

            ("Instalar Mozilla Firefox (Flatpak)", "flatpak install -y flathub org.mozilla.firefox"),

            ("Instalar LibreWolf (Flatpak)", "flatpak install -y flathub io.gitlab.librewolf-community"),

            ("Instalar Zen Browser (Flatpak)", "flatpak install -y flathub app.zen_browser.zen"),

            ("Instalar Opera GX (Flatpak)", "flatpak install -y flathub com.opera.opera-gx"),

            ("Instalar Vivaldi (Flatpak)", "flatpak install -y flathub com.vivaldi.Vivaldi")
        ]
        self.add_tab_content("Navegadores", items)

    def create_multimedia_tab(self):
        items = [
            ("Instalar Codecs Multimédia",
             "apt install -y faad ffmpeg gstreamer1.0-plugins-bad gstreamer1.0-plugins-good gstreamer1.0-plugins-ugly libavcodec-extra"),

            ("Instalar e Configurar Codecs para DVD criptografado",
             "echo 'libdvd-pkg libdvd-pkg/first-install select true' | debconf-set-selections && "
             "echo 'libdvd-pkg libdvd-pkg/process_libdvdcss select true' | debconf-set-selections && "
             "apt install -y libdvd-pkg && "
             "dpkg-reconfigure libdvd-pkg"),

            ("Instalar Compactadores/Extratores",
             "apt install -y arc arj cabextract lhasa p7zip p7zip-full p7zip-rar rar unrar unace unzip xz-utils zip"),

            ("Instalar Fontes da Microsoft",
             "apt install -y cabextract curl fontconfig xfonts-utils ttf-mscorefonts-installer"),

            ("Instalar VLC Player", "apt install -y vlc"),

            ("Instalar Audacious", "apt install -y audacious"),

            ("Instalar SMPlayer", "apt install -y smplayer"),

            ("Instalar Kodi", "apt install -y kodi"),

            ("Instalar Spotify",
             "curl -sS https://download.spotify.com/debian/pubkey_C85668DF69375001.gpg | gpg --dearmor | tee /etc/apt/keyrings/spotify.gpg > /dev/null && echo 'deb [arch=amd64 signed-by=/usr/share/keyrings/spotify.gpg] http://repository.spotify.com stable non-free' > /etc/apt/sources.list.d/spotify.list && apt update && apt install -y spotify-client"),

            ("Instalar o editor de áudio Audacity", "apt install -y audacity"),

            ("Instalar Handbrake", "apt install -y handbrake"),

            ("Instalar GIMP", "apt install -y gimp"),

            ("Instalar Krita", "apt install -y krita"),

            ("Instalar Blender", "apt install -y blender"),

            ("Instalar OBS Studio", "apt install -y obs-studio"),

            ("Instalar KDENLIVE", "apt install -y kdenlive"),

            ("Instalar Inkscape", "apt install -y inkscape"),

            ("Instalar Openshot", "apt install -y openshot-qt"),

            ("Instalar Discord (Flatpak)", "flatpak install -y flathub com.discordapp.Discord"),

            ("Instalar Portal for Teams (Não Oficial e Flatpak)", "flatpak install -y flathub com.github.IsmaelMartinez.teams_for_linux " ),

            ("Instalar Telegram", "apt install -y telegram-desktop"),

            ("Instalar Zoom (Flatpak)", "flatpak install -y flathub us.zoom.Zoom"),

            ("Instalar GIMP (Flatpak)", "flatpak install -y flathub org.gimp.GIMP"),

            ("Instalar Krita (Flatpak)", "flatpak install -y flathub org.kde.krita"),

            ("Instalar Blender (Flatpak)", "flatpak install -y flathub org.blender.Blender")
        ]
        self.add_tab_content("Multimédia e Apps", items)

    def create_virtualization_tab(self):
        real_user = os.environ.get("SUDO_USER", os.environ.get("USER", ""))
        items = [
            ("Instalar VirtualBox 7.2",
             "wget -O- -q https://www.virtualbox.org/download/oracle_vbox_2016.asc | gpg --dearmour -o /usr/share/keyrings/oracle_vbox_2016.gpg && "
             "echo 'deb [arch=amd64 signed-by=/usr/share/keyrings/oracle_vbox_2016.gpg] http://download.virtualbox.org/virtualbox/debian trixie contrib' > /etc/apt/sources.list.d/virtualbox.list && "
             "apt update && "
             "apt install -y virtualbox-7.2"),

            ("Adicionar usuário atual ao grupo vboxusers",
             f"usermod -a -G vboxusers {real_user}" if real_user else "echo 'Usuário não identificado para o grupo vboxusers'"),

            ("Instalar Virtual Machine Manager (Virt-Manager / QEMU)",
             "apt install -y virt-manager qemu-system libvirt-clients libvirt-daemon-system virtiofsd && "
             "systemctl enable libvirtd && "
             "systemctl start libvirtd"),

            ("Instalar o Gnome Boxes (Flatpak)", "flatpak install -y flathub org.gnome.Boxes")

        ]
        self.add_tab_content("Virtualização", items)

    def create_developers_tab(self):
        real_user = os.environ.get("SUDO_USER", os.environ.get("USER", "root"))
        real_home = f"/home/{real_user}" if real_user != "root" else "/root"

        items = [

            ("Instalar Python 3, Pip e Venv",
             "apt install -y python3 python3-dev python3-pip python3-venv libpython3-dev"),

            ("Instalar Miniconda",
             "curl -sL https://repo.anaconda.com/miniconda/Miniconda3-latest-Linux-x86_64.sh -o /tmp/miniconda.sh && "
             "bash /tmp/miniconda.sh -b -p /opt/conda && "
             "/opt/conda/bin/conda init bash && "
             "rm /tmp/miniconda.sh"
             ),

            ("Instalar Build-Essential, CMake e Ferramentas C/C++",
             "apt install -y build-essential ccache cmake autoconf automake libtool libssl-dev zlib1g-dev"),

            ("Instalar OpenJDK Java LTS 25 ", "apt install -y openjdk-25-jdk"),

            ("Instalar PHP", "apt install -y php-common libapache2-mod-php php-cli php-fpm php-mysql php-curl php-gd apache2"),

            ("Instalar NodeJS e NPM", "apt install -y nodejs npm"),

            ("Instalar MariaDB Server", "apt install -y mariadb-server"),

            ("Instalar PostgreSQL", "apt install -y postgresql postgresql-contrib"),

            ("Instalar Git, Curl e Wget", "apt install -y git curl wget"),

            ("Instalar Docker e Docker Compose",
             "apt install -y apt-transport-https ca-certificates curl gnupg && curl -fsSL https://download.docker.com/linux/debian/gpg -o /etc/apt/keyrings/docker.asc && echo 'deb [arch=amd64 signed-by=/usr/share/keyrings/docker.asc] https://download.docker.com/linux/debian trixie stable' > /etc/apt/sources.list.d/docker.list && apt update && apt install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin"),

            ("Instalar Podman","apt install -y podman && podman --version && podman run --rm quay.io/podman/hello"),

            ("Instalar Distrobox"," apt install -y distrobox"),

            ("Instalar Visual Studio Code",
             "wget -qO- https://packages.microsoft.com/keys/microsoft.asc | gpg --dearmor > /etc/apt/trusted.gpg.d/microsoft.gpg && echo 'deb [arch=amd64] https://packages.microsoft.com/repos/vscode stable main' > /etc/apt/sources.list.d/vscode.list && apt update && apt install -y code"),

            ("Instalar DBeaver Community (Flatpak)", "flatpak install -y flathub io.dbeaver.DBeaverCommunity")
        ]
        self.add_tab_content("Desenvolvimento", items)

    def create_games_tab(self):
        items = [

            ("Habilitar suporte a 32-bits e Instalar Steam (com dependências completas)",
             "dpkg --add-architecture i386 && "
             "apt update && "
             "apt install -y mesa-vulkan-drivers libglx-mesa0:i386 mesa-vulkan-drivers:i386 libgl1-mesa-dri:i386 steam"),

            ("Instalar Emulador DOLPHIN (GameCube/Wii - Flatpak)", "flatpak install -y flathub org.DolphinEmu.dolphin-emu"),

            ("Instalar Emulador CITRA (Nintendo 3DS - Flatpak) ", "flatpak install -y flathub org.citra_emu.citra"),

            ("Instalar o Emulador FLYCAST (Sega Dreamcast - Flatpak)", "flatpak install -y flathub org.flycast.Flycast"),

            ("Instalar Emulador PCSX2 (PlayStation 2 - Flatpak)", "flatpak install -y flathub net.pcsx2.PCSX2"),

            ("Instalar Emulador RPCS3 (Playstation 3 - Flatpak)", "flatpak install -y flathub net.rpcs3.RPCS3"),

            ("Instalar Emulador SNES9X (Super Nintendo - Flatpak)", "flatpak install -y flathub com.snes9x.Snes9x"),

            ("Instalar Emulador MGBA (Nintendo Game Boy Advance - Flatpak)", "flatpak install -y flathub io.mgba.mGBA"),

            ("Instalar Emulador XEMU (Microsoft Xbox - Flatpak)", "flatpak install -y flathub app.xemu.xemu"),

            ("Instalar Emulador YUZU (Nintendo Switch - Flatpak)", "flatpak install -y flathub org.yuzu_emu.yuzu"),

            ("Instalar Emulador Faugus (Windows Games - Flatpak)", "flatpak install -y flathub io.github.Faugus.faugus-launcher"),

            ("Instalar Bottles (Crossover Windows - Flatpak)", "flatpak install -y flathub com.usebottles.bottles")

        ]
        self.add_tab_content("Jogos e Emuladores", items)

    def create_hardware_tab(self):
        items = [
            ("Instalar Microcode Intel e Remover AMD", "apt install -y intel-microcode && apt remove -y amd64-microcode"),

            ("Instalar Microcode AMD e Remover Intel", "apt install -y amd64-microcode && apt remove -y intel-microcode"),

            ("Instalar Drivers NVIDIA Recentes", "apt install -y linux-headers-amd64 dkms nvidia-driver nvidia-smi nvidia-settings cuda"),

            ("Instalar GParted (Particionamento)", "apt install -y gparted"),

            ("Instalar GDebi e Synaptic (Para Pacotes Específicos)", "apt install -y gdebi synaptic"),

            ("Otimizar Zonas e Parâmetros Sysctl (Swappiness)",  "sysctl -w vm.swappiness=10 && sysctl -w vm.vfs_cache_pressure=50 && sysctl --system"),

            ("Melhorar bateria do Notebook (TLP)", "apt install -y tlp tlp-rdw && systemctl enable tlp && tlp start"),

            ("Atualizar Sistema (Apt e Flatpak)", "flatpak update -y && apt update && apt upgrade -y && apt autoremove -y"),

            ("Reiniciar o Sistema", "systemctl reboot"),

            ("Desligar a Máquina" , "systemctl poweroff")

        ]
        self.add_tab_content("Hardware e Sistema", items)

    def log(self, text):
        self.log_output.append(text)
        self.log_output.verticalScrollBar().setValue(self.log_output.verticalScrollBar().maximum())

    def run_selected_tasks(self):
        commands_to_run = []
        for cmd, chk in self.tasks.items():
            if chk.isChecked():
                commands_to_run.append(cmd)

        if not commands_to_run:
            QMessageBox.warning(self, "Aviso", "Nenhuma tarefa foi selecionada!")
            return

        full_command = " && ".join(commands_to_run)
        self.log(f"\n--- A INICIAR EXECUÇÃO DOS COMANDOS ---\n")

        self.btn_execute.setEnabled(False)
        self.worker = CommandWorker(full_command)
        self.worker.output_signal.connect(self.log)
        self.worker.finished_signal.connect(self.on_execution_finished)
        self.worker.start()

    def on_execution_finished(self, code):
        self.btn_execute.setEnabled(True)
        if code == 0:
            self.log("\n--- TODAS AS TAREFAS FORAM EXECUTADAS COM SUCESSO! ---\n")
            QMessageBox.information(self, "Sucesso", "Procedimento realizado com sucesso!")
        else:
            self.log(f"\n--- A EXECUÇÃO TERMINOU COM CÓDIGO DE ERRO: {code} ---\n")
            QMessageBox.warning(self, "Atenção", "Alguns comandos terminaram com erros. Verifique o log.")


if __name__ == "__main__":
    app = QApplication(sys.argv)

    # Verifica se NÃO é root
    if os.geteuid() != 0:
        script_path = os.path.abspath(sys.argv[0])

        # Captura as variáveis do ambiente gráfico atual
        display = os.environ.get("DISPLAY", ":0")
        xauth = os.environ.get("XAUTHORITY", "")

        try:
            # Passa o DISPLAY e XAUTHORITY junto com o pkexec para manter a interface gráfica visível
            os.execlp(
                "pkexec",
                "pkexec",
                "env",
                f"DISPLAY={display}",
                f"XAUTHORITY={xauth}",
                sys.executable,
                script_path,
                *sys.argv[1:]
            )
        except Exception as e:
            QMessageBox.critical(None, "Erro de Permissão",
                                 f"Não foi possível elevar os privilégios com pkexec.\nErro: {e}")
            sys.exit(1)

    window = DebianTrixieApp()
    window.show()
    sys.exit(app.exec())
